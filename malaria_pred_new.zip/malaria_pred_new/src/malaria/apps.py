from django.apps import AppConfig


class MalariaConfig(AppConfig):
    name = 'malaria'
